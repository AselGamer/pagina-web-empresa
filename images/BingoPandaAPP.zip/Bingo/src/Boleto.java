import java.awt.Color;
import java.awt.EventQueue;
import java.awt.Font;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.SwingConstants;
import javax.swing.Timer;
import javax.swing.border.EmptyBorder;
import javax.swing.border.LineBorder;
import java.awt.GridLayout;
import java.awt.Image;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Scanner;
import java.util.concurrent.ThreadLocalRandom;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JMenuBar;
import javax.swing.JMenu;
import javax.swing.JMenuItem;

public class Boleto extends JFrame {
	private static final long serialVersionUID = 1L;
	private JPanel contentPane;
	private JPanel boletos;
	private JButton nuevoBoleto;
	private JButton Linea;
	private JButton Bingo;
	private JButton Jugador;
	private static int boleto[][] = new int[3][9];;
	private static int marcados[][] = new int[3][9];;
	private Timer reloj;
	private Timer reloj2;
	int r =  ThreadLocalRandom.current().nextInt(1, 100 +1);
	String nombre = "Jugador"+r;
	String estado = "enpartida";
	boolean estadoLinea = false;
	boolean estadoBingo = false;
	boolean CartonAutomatico = false;
	boolean CartonAutomatico2 = true;
	boolean limpiar = false;
	boolean EnPartida = false;
	String linea;
	String bingo;
	private JMenuBar menuBar;
	private JMenu mnNewMenu;
	private JMenu mnNewMenu_1;
	private JMenuItem mntmNewMenuItem;
	
	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Boleto frame = new Boleto();
					Image icon = new ImageIcon(getClass().getResource("logo.png")).getImage();
					frame.setIconImage(icon);
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public Boleto() {
		setBounds(100, 100, 700, 500);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setDefaultCloseOperation(javax.swing.WindowConstants.DO_NOTHING_ON_CLOSE);
		addWindowListener(new java.awt.event.WindowAdapter() {
			@Override
			public void windowClosing(java.awt.event.WindowEvent evt) {
				close();
			}
		});
		
		menuBar = new JMenuBar();
		setJMenuBar(menuBar);
		
		mnNewMenu = new JMenu("Opciones");
		menuBar.add(mnNewMenu);
		
		mnNewMenu_1 = new JMenu("Carton");
		mnNewMenu.add(mnNewMenu_1);
		
		mntmNewMenuItem = new JMenuItem("Cambiar Automaticamente [Deshabilitado]");
		mntmNewMenuItem.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
			if(CartonAutomatico == false) {
				if (JOptionPane.showConfirmDialog(rootPane, "Al activar esta opcion, cada vez que se reinice la partida cambiara el carton ¿Desea habilitarla?","Cambiar la generacion de carton", JOptionPane.YES_NO_OPTION) == JOptionPane.YES_OPTION) {
					mntmNewMenuItem.setText("Cambiar Automaticamente [Habilitado]");
					CartonAutomatico = true;
		    	}    
			}
			
			else if(CartonAutomatico) {
				if (JOptionPane.showConfirmDialog(rootPane, "Al desactivar esta opcion, cada vez que se reinice la partida no se cambiara el carton ¿Desea deshabilitarla?","Cambiar la generacion de carton", JOptionPane.YES_NO_OPTION) == JOptionPane.YES_OPTION) {
					mntmNewMenuItem.setText("Cambiar Automaticamente [Deshabilitado]");
					CartonAutomatico = false;
		    	}    
			}
		}
	});
		mnNewMenu_1.add(mntmNewMenuItem);

		setContentPane(contentPane);
		contentPane.setLayout(new GridLayout(2, 0, 0, 0));
		
		boletos = new JPanel();
		contentPane.add(boletos);
		boletos.setLayout(new GridLayout(0, 9, 0, 0));
		
		JPanel opciones = new JPanel();
		contentPane.add(opciones);
		opciones.setLayout(new GridLayout(0, 2, 0, 0));
		
		

		JButton bolas[][] = new JButton[3][9];
		inicializar(bolas);
		
		marcados = mostrar(bolas);
		
		nuevoBoleto = new JButton("Nuevo Boleto");
		opciones.add(nuevoBoleto);
		nuevoBoleto.setBackground(Color.white);
		nuevoBoleto.setBorder(new LineBorder(Color.BLACK));
		nuevoBoleto.setFont(new Font("Arial",Font.BOLD, 30 ));
		nuevoBoleto.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				marcados = mostrar(bolas);
			}
		});
		
		Linea = new JButton("Línea");
		opciones.add(Linea);
		Linea.setBackground(Color.white);
		Linea.setBorder(new LineBorder(Color.BLACK));
		Linea.setFont(new Font("Arial",Font.BOLD, 30 ));
		Linea.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
			if(!estadoLinea) {
				if (linea()) {
					try {
						//SCANNEAR SI EXITO bingo.txt
						String archivoserver = "linea.txt";
			            FileWriter fw;
						fw = new FileWriter(archivoserver, true);
						String contenidoserver = nombre+"\r\n";    
				        fw.write(contenidoserver);
				        fw.close();
					} catch (Exception linea) {
						System.out.println("El fichero no existe.");			
					}
					System.out.println("LINEA ESTADO -> "+estadoLinea);
					System.out.println("CORRECTO LINEA");
				} else {
					JOptionPane.showMessageDialog(Boleto.this, "No tienes los numeros para cantar linea");				
				}
			} else {
				if(Jugador.getText().equals(linea)) {
					JOptionPane.showMessageDialog(Boleto.this, "Ya has cantado linea");
				} else {
					JOptionPane.showMessageDialog(Boleto.this, "Ya han cantando linea");
				}	
			}
		} 
		});
		
		Bingo = new JButton("Bingo");
		opciones.add(Bingo);
		Bingo.setBackground(Color.white);
		Bingo.setBorder(new LineBorder(Color.BLACK));
		Bingo.setFont(new Font("Arial",Font.BOLD, 30 ));
		Bingo.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
			if(!estadoBingo) {
				if (bingo()) {
					try {
						//AÑADIR ESTADO TRUE Y NOMBRE A bingo.txt
						String archivoserver = "bingo.txt";
			            FileWriter fw;
						fw = new FileWriter(archivoserver, true);
						String contenidoserver = nombre+"\r\n";    
				        fw.write(contenidoserver);
				        fw.close();
					} catch (Exception bingo) {
						System.out.println("El fichero no existe.");			
					}
					System.out.println("BINGO ESTADO -> "+estadoBingo);
					System.out.println("CORRECTO");	
				} else {
					JOptionPane.showMessageDialog(Boleto.this, "No tienes los numeros para cantar bingo");						
				}
			} else {
				if(Jugador.getText().equals(bingo)) {
					JOptionPane.showMessageDialog(Boleto.this, "Ya has cantado bingo");
				} else {
					JOptionPane.showMessageDialog(Boleto.this, "Ya han cantando bingo");
				}	
			}
		}	
		});
		
		Jugador = new JButton(nombre);
		opciones.add(Jugador);
		Jugador.setBackground(Color.white);
		Jugador.setBorder(new LineBorder(Color.BLACK));
		Jugador.setFont(new Font("Arial",Font.BOLD, 30 ));
		Jugador.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				nombre = JOptionPane.showInputDialog(Boleto.this, "Introduce tu nombre de jugador", nombre);
				Jugador.setText(nombre);
				if(nombre == null || nombre.isEmpty()) {
					nombre ="Jugador"+r;
					System.out.println("Cancelado");
					Jugador.setText(nombre);
				}
			}
		});
	}
	
	
	
		private void EnPartida(String estado) {
			if(EnPartida == false && estado.equals("enpartida")) {
				Linea.setEnabled(false);
				Bingo.setEnabled(false);
				nuevoBoleto.setEnabled(true);
				Jugador.setEnabled(true);
				reloj2.stop();
			}
		}
	
		//DETECTAR EL ESTADO DE LA PARTIDA
		private void estado(JButton bolas[][]) {
			reloj = new Timer(100, new ActionListener() {
				
				@Override
				public void actionPerformed(ActionEvent e) {	
					try {
						File archivo = new File ("estado.txt");
						FileReader fr;
						fr = new FileReader (archivo);
						BufferedReader br = new BufferedReader(fr);
						try {
						 	estado = br.readLine();
						 	br.close();
						} catch (IOException e1) {
							e1.printStackTrace();
						}
					} catch (FileNotFoundException e1) {
						e1.printStackTrace();
					}
					if (estado == null) estado = "";
					
					if(estado.equals("pausa")){
						Jugador.setEnabled(false);
						nuevoBoleto.setEnabled(false);
					} else if(estado.equals("sincomenzar")){
						estadoLinea = false;
						estadoBingo = false;
						Jugador.setEnabled(true);
						nuevoBoleto.setEnabled(true);
						EnPartida = true;
						Bingo.setEnabled(true);
						Linea.setEnabled(true);
						reloj2.start();
						if(CartonAutomatico && CartonAutomatico2 == true) {
							marcados = mostrar(bolas);
							CartonAutomatico2 = false;
						}
						if(limpiar) {
							colorear(bolas);
							limpiar = false;
							
						}
					} else if(estado.equals("finalizado")){
						Jugador.setEnabled(true);
						nuevoBoleto.setEnabled(true);
						EnPartida = true;
					} else if(estado.equals("enpartida")){
						Jugador.setEnabled(false);
						nuevoBoleto.setEnabled(false);
						CartonAutomatico2 = true;
						EnPartida(estado);
						limpiar = true;
					}
				}
			});
		}
		
		
		
	
		//CONSTRUIR PROGRAMA
	
	
	// FUNCIONES 
	public void inicializar(JButton[][] bolas) {

		//GENERAMOS LAS 90 BOLAS
		for (int i = 0; i < bolas.length;i++) {
			for (int j = 0; j < bolas[i].length;j++) {
				bolas[i][j] = new JButton();
				bolas[i][j].setHorizontalAlignment(SwingConstants.CENTER);
				bolas[i][j].setFont(new Font("Arial",Font.BOLD, 30));
				bolas[i][j].setBorder(new LineBorder(Color.BLACK));
				bolas[i][j].setOpaque(true);
				bolas[i][j].addActionListener(marcar(bolas[i][j], i, j));
				boletos.add(bolas[i][j]);
			}
		}
		
		estado(bolas);
		reloj.start();
		lineabingo();
		reloj2.start();
	}
	
	//MOSTRAR TODAS LAS BOLAS Y FILTRO PARA QUE APAREZCA EN CADA COLUMNA DE 1 a 2 ESPACIOS VACIOS.
	public static int[][] mostrar(JButton bolas[][]) {
		int marcados[][] = new int[3][9];
		for (int i = 0;i < marcados.length;i++) {
			int maxNums = 5;
			
			if (i < marcados.length-1) {
				
				ArrayList<Integer> list = new ArrayList<Integer>();
				for (int x = 0; x < 9; x++) {
					if (x < 4) list.add(0);
					else list.add(91);
				}
				Collections.shuffle(list);
				for (int x = 0; x < list.size(); x++) marcados[i][x] = list.get(x);

			} else {
				for (int x = 0; x < marcados[i].length; x++) {
					if (marcados[0][x] == 0 && marcados[1][x] == 0) {
						marcados[i][x] = 91;
						maxNums--;
					}
				}
				for (int x = 0; maxNums > 0;x++) {
					if (x > 8) x = 0;
					if (marcados[i][x] == 0 && 1 == (int)(Math.random()*2)) {
						marcados[i][x] = 91;
						maxNums--;
					}
				}
			}
		}

		int min = 1, max = 10;
		for (int i = 0; i < boleto[0].length;i++) {
			
			ArrayList<Integer> list = new ArrayList<Integer>();
			for (int x = min; x <= max; x++) list.add(x);
			Collections.shuffle(list);
			int nums[] = { list.get(0), list.get(1), list.get(2) };
			Arrays.sort(nums);
			for (int x = 0; x < nums.length;x++) {
				if (marcados[x][i] == 91) {
					boleto[x][i] = nums[x];
				} else {
					boleto[x][i] = marcados[x][i];
				}
			}
			min+=10;
			max+=10;
		}
		
		for (int i = 0;i<boleto.length;i++) {
			for (int x = 0;x<boleto[i].length;x++) {
				if (marcados[i][x] == 91) {
					System.out.println(x+" "+i);
					bolas[i][x].setText(""+boleto[i][x]);
					bolas[i][x].setEnabled(true);
					bolas[i][x].setBackground(Color.white);
				} else {
					bolas[i][x].setText("");
					bolas[i][x].setEnabled(false);
					bolas[i][x].setBackground(Color.gray);
				}
				System.out.print(boleto[i][x]+" ");
			}
			System.out.println();
		}
		
		return marcados;
	}

	private static void colorear(JButton[][] bolas) {
		for (int i = 0;i<bolas.length;i++) {
			for (int x = 0;x<bolas[i].length;x++) {
				if (marcados[i][x] != 0) bolas[i][x].setBackground(Color.white);
				else bolas[i][x].setBackground(Color.GRAY);
			} 
		}
	}
	
	
	//MARCAR CASILLA O DESMARCARLA DE COLOR VERDE/BLANCO
	private ActionListener marcar(final JButton btn, int line, int elem) {
		return new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				//SI EL COLOR DEL FONDO ES BLANCO CAMBIAR A VERDE Y AÑADIR EL NUMERO A LA LISTA DE (MARCADORS)
				if(btn.getBackground().equals(Color.white)) {
					marcados[line][elem] = Integer.parseInt(btn.getText());
					btn.setBackground(new Color(120, 214, 128));
				} else {
					marcados[line][elem] = 91;
					btn.setBackground(Color.white);
				}
				//PREVISUALIZAR EN CONSOLA CADA VEZ QUE SE MARCA / DESMARCAR
				for (int i = 0; i < marcados.length;i++) {
					for (int j = 0; j < marcados[i].length;j++) System.out.print(marcados[i][j]+" ");
					System.out.println();
				}
				System.out.println();
			}
		};
	}
	//DETECTAR SI ALGUIEN CANTO LINEA O BINGO 
	public void lineabingo () {
		reloj2 = new Timer(100, new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				if (!estadoLinea) {
					try {
						File archivo = new File ("linea.txt");
						FileReader fr;
						fr = new FileReader (archivo);
						BufferedReader br = new BufferedReader(fr);
						try {
							linea = br.readLine();	
							if (linea == null) linea = "";
							br.close();
						} catch (IOException err) {
							err.printStackTrace();
						}
					} catch (FileNotFoundException pa) {
						pa.printStackTrace();
					}
					if (linea == null) linea = "";
					if(!linea.equals("")) {
						estadoLinea=true;
						Linea.setEnabled(false);
						if(Jugador.getText().equals(linea)) {
							JOptionPane.showMessageDialog(Boleto.this, "¡ENHORABUENA, HAS CANTADO LINEA!");
						} else {
							JOptionPane.showMessageDialog(Boleto.this, "¡El jugador a "+linea+" canto linea!");
						}	
					}
				}
				if (!estadoBingo) {
					try {
						File archivo = new File ("bingo.txt");
						FileReader fr;
						fr = new FileReader (archivo);
						BufferedReader br = new BufferedReader(fr);
						try {
							bingo = br.readLine();
							if (bingo == null) bingo = "";
							br.close();
						} catch (IOException err) {
							err.printStackTrace();
						}
					} catch (FileNotFoundException ej) {
						ej.printStackTrace();
					}
					if (bingo == null) bingo = "";
					
					if(!bingo.equals("")) {
						System.out.println(bingo);
						estadoBingo=true;
						Bingo.setEnabled(false);
						reloj2.stop();
						if(Jugador.getText().equals(bingo)) {
							JOptionPane.showMessageDialog(Boleto.this, "¡ENHORABUENA, HAS CANTADO BINGO!");
						} else {
							JOptionPane.showMessageDialog(Boleto.this, "¡El jugador "+bingo+" a cantado bingo!");
						}	
					}
				}
			}
		});
	}
	
	//CERRAR PESTAÑA AL PREGUNTAR
		private void close(){
	        if (JOptionPane.showConfirmDialog(rootPane, "¿Desea cerrar el carton? No podras jugar hasta que acabe la partida","Salir del sistema", JOptionPane.YES_NO_OPTION) == JOptionPane.YES_OPTION) {
	        	System.exit(0);
	    	}                
		}
		
	//DETECTAR LINEA
	public static boolean linea() {
		
		boolean line = false;
		int winners[] = new int[90];
		int x = 0;
		try {
			Scanner scFile= new Scanner(new File("server.txt"));
			while (scFile.hasNext()) winners[x++] = Integer.parseInt(scFile.nextLine());
		} catch (Exception err) {
			System.out.println(err);
		}

		for (int i = 0; i < marcados.length;i++) {
			for (int j = 0;j < marcados[i].length;j++) {
				int n = marcados[i][j];
				if (n == 91) {
					line = false;
					break;
				} else if (n != 0) {
					for (x = 0;x < winners.length;x++) {
						if (n == winners[x]) {
							line = true;
							break;
						} else line = false;
					}
					if (!line) break;
				}
			}
			if (line) break;
		}

		return line;
	}
	
	
	//DETECTAR BINGO
	public static boolean bingo() {
		boolean state = false;
		
		for (int i = 0;i < marcados.length;i++) {
			for (int j = 0;j < marcados[i].length;j++) if (marcados[i][j] == 91) return state;
		}

		try {
			Scanner scFile= new Scanner(new File("server.txt"));
			ArrayList<String> elems = new ArrayList<String>();
			while(scFile.hasNext()) elems.add(scFile.nextLine()); 
			
			for (int i = 0; i < marcados.length;i++) {
				for (int j = 0; j < marcados[i].length;j++) {
					if (marcados[i][j] != 0) {
						for (int e = 0;e < elems.size();e++) {
							if (marcados[i][j] == Integer.parseInt(elems.get(e))) {
								System.out.print(elems.get(e)+" ");
								state = true;
								break;
							} else state = false;
						}
						if (!state) return state;
					}
				}
			}
			scFile.close();
		} catch (Exception e) {
			System.out.println("ERROR: El fichero no existe.");			
		}

		return state;
	}

}