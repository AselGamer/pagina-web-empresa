import java.awt.Color;
import java.awt.EventQueue;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.SwingConstants;
import javax.swing.Timer;
import javax.swing.border.EmptyBorder;
import javax.swing.border.LineBorder;
import java.awt.GridLayout;
import java.awt.Image;
import java.awt.Toolkit;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.Collections;
import java.awt.event.ActionEvent;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.Font;

public class Bingo extends JFrame {
	private static final long serialVersionUID = 1L;
	private JPanel contentPane;
	private JPanel menu;
	private JPanel opciones;
	private JPanel panelbolas;
	private JLabel[] bolas;
	private JButton Pausar;
	private JButton Generador;
	private boolean pausa = false;
	private boolean automatico = true;
	boolean estadoLinea = false;
	boolean estadoBingo = false;
	private Timer reloj;
	private Timer reloj2;
	boolean resaltar = true;
	boolean riloj = false;
	String estado;
	String linea;
	String bingo;
	int numero;
	int numero2 = -1;
	int bolaaresaltar;
	int cont;
	int numeros[] = new int[90];
	ArrayList<Integer> list = new ArrayList<Integer>(); 
	

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Bingo frame = new Bingo();
					//Image icon = Toolkit.getDefaultToolkit().getImage("../Bingo/logo.png");
					Image icon = new ImageIcon(getClass().getResource("logo.png")).getImage();
					frame.setIconImage(icon);
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public Bingo() {
		
		setBounds(1, 100, 1000, 500);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setDefaultCloseOperation(javax.swing.WindowConstants.DO_NOTHING_ON_CLOSE);
        addWindowListener(new java.awt.event.WindowAdapter() {
            @Override
            public void windowClosing(java.awt.event.WindowEvent evt) {
                close();
            }
        });
 
    

		setContentPane(contentPane);
		contentPane.setLayout(new GridLayout(0, 2, 0, 0));
		
		panelbolas = new JPanel();
		contentPane.add(panelbolas);
		panelbolas.setLayout(new GridLayout(0, 10, 0, 0));
		
		menu = new JPanel();
		contentPane.add(menu);
		menu.setLayout(new GridLayout(2, 1, 0, 0));
		
		JLabel numeros = new JLabel("¡BINGO!");
		numeros.setFont(new Font("Arial",Font.BOLD, 120 ));
		numeros.setHorizontalAlignment(SwingConstants.CENTER);
		menu.add(numeros);
		
		opciones = new JPanel();
		menu.add(opciones);
		opciones.setLayout(new GridLayout(2, 2, 0, 0));
		
		JButton Iniciar = new JButton("Iniciar Partida");
		Iniciar.setFont(new Font("Arial",Font.BOLD, 30 ));
		Iniciar.setBackground(Color.white);
		opciones.add(Iniciar);
		Iniciar.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
			if(automatico) {
				if (Iniciar.getText().equals("Iniciar Partida")) {
					Iniciar.setText("Reiniciar Partida");
					Pausar.setEnabled(true);
					estado("enpartida");
					pausa = false;
				} else {
					if (JOptionPane.showConfirmDialog(rootPane, "Al reiniciar partida se empezara una nueva, ¿Estas seguro de reiniciar?","Reiniciar partida", JOptionPane.YES_NO_OPTION) == JOptionPane.YES_OPTION) {
					cont = 0;
					Iniciar.setText("Iniciar Partida");
					numeros.setText("¡BINGO!");
					reloj.stop();
					reloj2.start();
					estado("sincomenzar");
					colorear(bolas);
					vaciararchivos();
					Collections.shuffle(list); 
					Pausar.setText("Iniciar");
					Pausar.setEnabled(false);
					estadoLinea = false;
					estadoBingo = false;
						}
					}
				} else {
					if (Iniciar.getText().equals("Iniciar Partida")) {
						Iniciar.setText("Reiniciar Partida");
						Pausar.setEnabled(true);
						estado("enpartida");
						pausa = false;
					} else {
						if (JOptionPane.showConfirmDialog(rootPane, "Al reiniciar partida se empezara una nueva, ¿Estas seguro de reiniciar?","Reiniciar partida", JOptionPane.YES_NO_OPTION) == JOptionPane.YES_OPTION) {
						cont = 0;
						Iniciar.setText("Iniciar Partida");
						numeros.setText("¡BINGO!");
						reloj2.start();
						pausa = true;
						estado("sincomenzar");
						colorear(bolas);
						vaciararchivos();
						Collections.shuffle(list); 
						Pausar.setEnabled(false);
						estadoLinea = false;
						estadoBingo = false;
						}
					}
				}
			} 		
		});
		
		Pausar = new JButton("Iniciar");
		Pausar.setFont(new Font("Arial",Font.BOLD, 30 ));
		Pausar.setBackground(Color.white);
		opciones.add(Pausar);
		Pausar.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
			if(automatico)	{
				if( cont == 0) {
					pausa = false;
					reloj.start();
					estado("enpartida");
					Pausar.setText("Pausar");
				} else {
				if (pausa) {
					pausa = false;
					reloj.start();
					estado("enpartida");
					Pausar.setText("Pausar");
				} else {
					pausa = true;
					reloj.stop();
					estado("pausa");
					Pausar.setText("Continuar");
					}
				}
			} else {
				sacarBola(numeros,bolas);
				pausa = false;
				
				
		} 
			}
		});
		Pausar.setEnabled(false);
		
		JButton Salir = new JButton("Salir");
		Salir.setFont(new Font("Arial",Font.BOLD, 30 ));
		Salir.setBackground(Color.white);
		opciones.add(Salir);
		Salir.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				if ( Pausar.getText().equals("Pausar")) Pausar.setText("Continuar");
				pausa = true;
				//PIDE CONFIRMACIO PARA DAR POR FINALIZADO EL PROGRAMA
				if (JOptionPane.showConfirmDialog(rootPane, "¿Desea cerrar el bingo? Se perdera todos los datos","Salir del sistema", JOptionPane.YES_NO_OPTION) == JOptionPane.YES_OPTION) {
					 System.out.println("Bingo Cerrado");
	            	 estado("sincomenzar");
					 System.exit(1);
				}
				
			}
			
		});



		Generador = new JButton("Automatico");
		Generador.setFont(new Font("Arial",Font.BOLD, 30 ));
		opciones.add(Generador);
		Generador.setBackground(Color.white);
		Generador.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				pausa = true;
				reloj.stop();
				if(automatico) {
					Generador.setText("Manual");
					Pausar.setText("Generar");
					automatico = false;
					pausa = false;
					if(estadoBingo) {
					estado("finalizado");
					}
				} else {
					Generador.setText("Automatico");
					Pausar.setText("Continuar");
					if(estadoBingo) {
						estado("finalizado");
						} else {
					estado("pausa");
						}
					automatico = true;
					if ( cont == 0) {
						Pausar.setText("Iniciar");
					}
				}
				
			}
			
		});
		
		bolas = new JLabel[90];
		inicializar(bolas);
		sacarBola(numeros,bolas);
		estado("sincomenzar");
		
		
	}
		//CONSTRUIR PROGRAMA
	
	
	// FUNCIONES 
	public void inicializar(JLabel[] bolas) {

		//GENERAMOS LAS 90 BOLAS
		for (int i = 0; i < 90; i++) {
			bolas[i] = new JLabel();
			bolas[i].setHorizontalAlignment(SwingConstants.CENTER);
			bolas[i].setText(""+(i+1));
			bolas[i].setFont(new Font("Arial",Font.BOLD, 30));
			bolas[i].setBorder(new LineBorder(Color.BLACK));
			bolas[i].setOpaque(true);
			panelbolas.add(bolas[i]);
		}
		
		estadoLinea = false;
		estadoBingo = false;
		
		colorear(bolas);
		vaciararchivos();
		llenarlista();
		lineabingo();
		reloj2.start();
	}
	
	
	public void vaciararchivos() {
		//VACIAR LINEA.txt
		try {
		PrintWriter	pwbingo = new PrintWriter(new File("bingo.txt"));
		pwbingo.println("");
		} catch (FileNotFoundException e) {
			
			e.printStackTrace();
		}
		//VACIAR BINGO.txt
		try {
			PrintWriter	pwlinea = new PrintWriter(new File("linea.txt"));
			pwlinea.println("");
			} catch (FileNotFoundException e) {
				
				e.printStackTrace();
			}
		//VACIAR SERVER.txt
		try {
			PrintWriter	pwserver = new PrintWriter(new File("server.txt"));
			pwserver.println("");
			} catch (FileNotFoundException e) {
				e.printStackTrace();
			}
	}
	
	
	
	//COLOREAR EN PATRON DE AJEDREZ
	public void colorear(JLabel[] bolas) {
		for (int i = 0; i < bolas.length; i++) {
			bolas[i].setBackground(Color.white);
		}
		for (int i = 0, j = i; i < bolas.length; i+=2, j+=2) {	
			if (j % 10 == 0 && j != 0) {
				j = 1;
				i++;
			} else if (j % 11 == 0 && j != 0) {
				j = 0;
				i--;
			}
			bolas[i].setBackground(new Color(65, 201, 242));
		}
	}
	//LLENAMOS LA LISTA
	public void llenarlista() {
        for (int i = 1; i < 91; i++) list.add(i); 
        Collections.shuffle(list); 
	}
	
	
	public void estado(String estado) {
			if (estado.equals("pausa")) {
				try {
					PrintWriter	pwestado = new PrintWriter(new File("estado.txt"));
					pwestado.println("pausa");
					pwestado.close();
					} catch (FileNotFoundException pausa) {
						System.out.print("ARCHIVO NO ENCONTRADO");
					}
			} else if(estado.equals("sincomenzar")) {
				try {
					PrintWriter	pwestado = new PrintWriter(new File("estado.txt"));
					pwestado.println("sincomenzar");
					pwestado.close();
					} catch (FileNotFoundException pausa) {
						System.out.print("ARCHIVO NO ENCONTRADO");
					}
			} else if(estado.equals("finalizado")) {
				try {
					PrintWriter	pwestado = new PrintWriter(new File("estado.txt"));
					pwestado.println("finalizado");
					pwestado.close();
					} catch (FileNotFoundException pausa) {
						System.out.print("ARCHIVO NO ENCONTRADO");
					}
			} else if(estado.equals("enpartida")) {
				try {
					PrintWriter	pwestado = new PrintWriter(new File("estado.txt"));
					pwestado.println("enpartida");
					pwestado.close();
					} catch (FileNotFoundException pausa) {
						System.out.print("ARCHIVO NO ENCONTRADO");
					}
				}
		}
	
	
	
	//DETECTAR LINEA O BINGO 
	public void lineabingo () {
		reloj2 = new Timer(100, new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				
				if (!estadoLinea) {
					try {
						File archivo = new File ("linea.txt");
						FileReader fr;
						fr = new FileReader (archivo);
						BufferedReader br = new BufferedReader(fr);
						try {
							 linea = br.readLine();
							 if (linea == null) linea = "";
							 br.close();
						} catch (IOException e1) {
							e1.printStackTrace();
						}
					} catch (FileNotFoundException e1) {
						e1.printStackTrace();
					}

					if(!linea.equals("")) {
						estadoLinea=true;
						if(automatico) {
							reloj.stop();
							pausa = true;
							Pausar.setText("Continuar");
							JOptionPane.showMessageDialog(Bingo.this, "El jugador "+linea+" canto linea");
						} else {
							JOptionPane.showMessageDialog(Bingo.this, "El jugador "+linea+" canto linea");
						}
					}
				}
				if (!estadoBingo) {
					try {
						File archivo = new File ("bingo.txt");
						FileReader fr;
						fr = new FileReader (archivo);
						BufferedReader br = new BufferedReader(fr);
						try {
							 bingo = br.readLine();
							 if (bingo == null) bingo = "";
							 br.close();
						} catch (IOException e1) {
							e1.printStackTrace();
						}
					} catch (FileNotFoundException e1) {
						e1.printStackTrace();
					}
					
					if(!bingo.equals("")) {
						if(automatico) {
							reloj.stop();
							pausa = true;
							estadoBingo=true;
							JOptionPane.showMessageDialog(Bingo.this, "¡El jugador "+bingo+" canto bingo!");
							estado("finalizado");
							pausa = true;
							Pausar.setText("Continuar");
							Pausar.setEnabled(false);
							
							
						} else {
							reloj.stop();
							reloj2.stop();
							estadoBingo=true;
							JOptionPane.showMessageDialog(Bingo.this, "¡El jugador "+bingo+" canto bingo!");
							estado("finalizado");
							Pausar.setEnabled(false);
						}
						
					}
				}
				
				if (estadoBingo) {
					reloj.stop();
					reloj2.stop();
				}
				
			}
		});
	}
	
	//CERRAR PESTAÑA AL PREGUNTAR
	private void close(){
        if (JOptionPane.showConfirmDialog(rootPane, "¿Desea cerrar el bingo? Se perdera todos los datos","Salir del sistema", JOptionPane.YES_NO_OPTION) == JOptionPane.YES_OPTION) {
        	vaciararchivos();
        	estado("sincomenzar");
        	System.exit(0);
    	}                
	}
	
	//SACAMOS 1 BOLA
	public void sacarBola(JLabel text, JLabel[] bolas) {	
	if(automatico) {
		reloj = new Timer(4000, new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				System.out.println(cont);
				if (cont == 90) {
					Pausar.setEnabled(false);
					estado("finalizado");
				}
				if (cont != 90 && pausa == false) {
					int num = list.get(cont++);
					text.setText(num+"");
					for (int i = 0; i < bolas.length;i++) {
						if (i == num-1) {
							bolas[i].setBackground(Color.GREEN);
							//AÑADIR BOLA A LA LISTA
							try {
								String archivoserver = "server.txt";
					            FileWriter fw;
								fw = new FileWriter(archivoserver, true);
								String contenidoserver = num+"\r\n";    
						        fw.write(contenidoserver);
						        fw.close();
							} catch (IOException e1) {
								System.out.print("ARCHIVO NO ENCONTRADO");
							}    
				           
						}
					}
				} else {
					reloj.stop();
				}
				
			}
		
			});
		} else {
			System.out.println("GENERAR");
			if (cont != 90 && pausa == false) {
				int num = list.get(cont++);
				if (cont == 90) {
					Pausar.setEnabled(false);
					estado("finalizado");
				}
				text.setText(num+"");
				for (int i = 0; i < bolas.length;i++) {
					if (i == num-1) {
						bolas[i].setBackground(Color.GREEN);
						try {
							String archivoserver = "server.txt";
				            FileWriter fw;
							fw = new FileWriter(archivoserver, true);
							String contenidoserver = num+"\r\n";    
					        fw.write(contenidoserver);
					        fw.close();
						} catch (IOException e1) {
							System.out.print("ARCHIVO NO ENCONTRADO");
						}  
					}
				}
			} 
		}
	}
	
}
